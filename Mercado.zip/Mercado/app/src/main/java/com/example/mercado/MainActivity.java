package com.example.mercado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    double vmaca,vbanana,vpera,vuva;

    CheckBox ch_Maca, ch_Banana, ch_Pera, ch_Uva;

    EditText P_Maca,P_Banana,P_Pera,P_Uva;

    TextView txt_Total;

    Button btn_calular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch_Maca = findViewById(R.id.ch_Maca);
        ch_Banana = findViewById(R.id.ch_Banana);
        ch_Pera = findViewById(R.id.ch_Pera);
        ch_Uva = findViewById(R.id.ch_Uva);

        P_Maca = findViewById(R.id.P_Maca);
        P_Banana = findViewById(R.id.P_Banana);
        P_Pera = findViewById(R.id.P_Pera);
        P_Uva = findViewById(R.id.P_Uva);

        txt_Total = findViewById(R.id.txt_Total);

        btn_calular = findViewById(R.id.btn_calcular);

        vmaca = 0.25;
        vbanana = 0.20;
        vpera = 0.15;
        vuva = 0.10;

    }
}