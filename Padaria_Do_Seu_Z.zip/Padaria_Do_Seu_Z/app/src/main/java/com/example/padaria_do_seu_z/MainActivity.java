package com.example.padaria_do_seu_z;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    int vpao,vbolo,vbaguete,vpaoDoce,vtotalPao;
    CheckBox ch_pao,ch_bolo,ch_baguete,ch_paoDoce;

    EditText P_pao,P_bolo,P_baguete,P_paoDoce;

    TextView txt_pao,txt_bolo,txt_baguete,txt_paoDoce;

    Button btn_retirar;
    Button btn_adicionar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch_pao = findViewById(R.id.ch_Pao);
        ch_bolo = findViewById(R.id.ch_bolo);
        ch_baguete = findViewById(R.id.ch_baguete);
        ch_paoDoce = findViewById(R.id.ch_PaoDoce);

        P_pao = findViewById(R.id.edt_pao);
        P_bolo = findViewById(R.id.edt_bolo);
        P_baguete = findViewById(R.id.edt_baguete);
        P_paoDoce = findViewById(R.id.edt_PaoDoce);

        txt_pao = findViewById(R.id.txt_Pao);
        txt_bolo = findViewById(R.id.txt_bolo);
        txt_baguete = findViewById(R.id.txt_baguete);
        txt_paoDoce = findViewById(R.id.txt_paoDoce);

        btn_retirar = findViewById(R.id.btn_estoque);
        btn_adicionar = findViewById(R.id.btn_adicionar);

        txt_pao.setText(txt_pao.getText().toString()+vpao);
        txt_bolo.setText(txt_pao.getText().toString()+vbolo);
        txt_baguete.setText(txt_baguete.getText().toString()+vbaguete);
        txt_paoDoce.setText(txt_paoDoce.getText().toString()+vpaoDoce);

    }


    public void adicionar(View v){


        if(ch_pao.isChecked()){

            txt_pao.setText("Quantidade de Pães:");

            vpao = (int) Double.parseDouble(P_pao.getText().toString());

            txt_pao.setText(txt_pao.getText().toString()+ vpao);

            P_pao.setText("");
            ch_pao.toggle();

        }

        if(ch_bolo.isChecked()){

            txt_bolo.setText("Quantidade de Bolos:");

            vbolo = (int) Double.parseDouble(P_bolo.getText().toString());

            txt_bolo.setText(txt_bolo.getText().toString()+ vbolo);

            P_bolo.setText("");
            ch_bolo.toggle();


        }

        if(ch_baguete.isChecked()){

            txt_baguete.setText("Quantidade de Baguetes:");

            vbaguete = (int) Double.parseDouble(P_baguete.getText().toString());

            txt_baguete.setText(txt_baguete.getText().toString()+ vbaguete);

            P_baguete.setText("");
            ch_baguete.toggle();

        }

        if(ch_paoDoce.isChecked()){

            txt_paoDoce.setText("Quantidade de Pães Doce:");

            vpaoDoce = (int) Double.parseDouble(P_paoDoce.getText().toString());

            txt_paoDoce.setText(txt_paoDoce.getText().toString()+ vpaoDoce);

            P_paoDoce.setText("");
            ch_paoDoce.toggle();

        }

        Toast.makeText(this, "Produto adicionado ao Estoque com sucesso",Toast.LENGTH_LONG).show();


    }


    public void calcular(View v){

        if(ch_pao.isChecked()) {

            if ((int) Double.parseDouble(P_pao.getText().toString()) > vpao) {

                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Impossivel Retirar do Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            } else {

                if (vpao == 0) {

                    AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                    cxMsg.setMessage("Produto fora de Estoque");
                    cxMsg.setNeutralButton("OK", null);
                    cxMsg.show();

                } else {

                    txt_pao.setText("Quantidade de Pães:");

                    vpao = (int) (vpao - Double.parseDouble(P_pao.getText().toString()));

                    txt_pao.setText(txt_pao.getText().toString() + vpao);

                    P_pao.setText("");
                    ch_pao.toggle();

                }


            }
        }

        if(ch_bolo.isChecked()) {

            if ((int) Double.parseDouble(P_bolo.getText().toString()) > vbolo) {

                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Impossivel Retirar do Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            } else {

                if (vbolo == 0) {

                    AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                    cxMsg.setMessage("Produto fora de Estoque");
                    cxMsg.setNeutralButton("OK", null);
                    cxMsg.show();

                } else {

                    txt_bolo.setText("Quantidade de Bolos:");

                    vbolo = (int) (vbolo - Double.parseDouble(P_bolo.getText().toString()));

                    txt_bolo.setText(txt_bolo.getText().toString() + vbolo);

                    P_bolo.setText("");
                    ch_bolo.toggle();

                }


            }
        }

        if(ch_baguete.isChecked()) {

            if ((int) Double.parseDouble(P_baguete.getText().toString()) > vbaguete) {

                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Impossivel Retirar do Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            } else {

                if (vbaguete == 0) {

                    AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                    cxMsg.setMessage("Produto fora de Estoque");
                    cxMsg.setNeutralButton("OK", null);
                    cxMsg.show();

                } else {

                    txt_baguete.setText("Quantidade de Baguetes:");

                    vbaguete = (int) (vbaguete - Double.parseDouble(P_baguete.getText().toString()));

                    txt_baguete.setText(txt_baguete.getText().toString() + vbaguete);

                    P_baguete.setText("");
                    ch_baguete.toggle();

                }


            }
        }

        if(ch_paoDoce.isChecked()) {

            if ((int) Double.parseDouble(P_paoDoce.getText().toString()) > vpaoDoce) {

                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Impossivel Retirar do Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            } else {

                if (vpaoDoce == 0) {

                    AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                    cxMsg.setMessage("Produto fora de Estoque");
                    cxMsg.setNeutralButton("OK", null);
                    cxMsg.show();

                } else {

                    txt_paoDoce.setText("Quantidade de Pães Doces:");

                    vpaoDoce = (int) (vpaoDoce - Double.parseDouble(P_paoDoce.getText().toString()));

                    txt_paoDoce.setText(txt_paoDoce.getText().toString() + vpaoDoce);

                    P_paoDoce.setText("");
                    ch_paoDoce.toggle();

                }


            }
        }

    }
}