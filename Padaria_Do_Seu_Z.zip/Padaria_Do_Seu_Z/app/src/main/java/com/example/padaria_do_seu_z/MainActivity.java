package com.example.padaria_do_seu_z;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    int vpao,vbolo,vbaguete,vpaoDoce,vtotalPao;
    CheckBox ch_pao,ch_bolo,ch_baguete,ch_paoDoce;

    EditText P_pao,P_bolo,P_baguete,P_paoDoce;

    TextView txt_pao,txt_bolo,txt_baguete,txt_paoDoce;

    Button btn_retirar;
    Button btn_adicionar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch_pao = findViewById(R.id.ch_Pao);
        ch_bolo = findViewById(R.id.ch_bolo);
        ch_baguete = findViewById(R.id.ch_baguete);
        ch_paoDoce = findViewById(R.id.ch_PaoDoce);

        P_pao = findViewById(R.id.edt_pao);
        P_bolo = findViewById(R.id.edt_bolo);
        P_baguete = findViewById(R.id.edt_baguete);
        P_paoDoce = findViewById(R.id.edt_PaoDoce);

        txt_pao = findViewById(R.id.txt_Pao);
        txt_bolo = findViewById(R.id.txt_bolo);
        txt_baguete = findViewById(R.id.txt_baguete);
        txt_paoDoce = findViewById(R.id.txt_paoDoce);

        btn_retirar = findViewById(R.id.btn_estoque);
        btn_adicionar = findViewById(R.id.btn_adicionar);

        txt_bolo.setText(txt_pao.getText().toString()+vbolo);
        txt_baguete.setText(txt_baguete.getText().toString()+vbaguete);
        txt_paoDoce.setText(txt_paoDoce.getText().toString()+vpaoDoce);

    }


    public void adicionar(View v){


        if(ch_pao.isChecked()){


            vpao = (int) Double.parseDouble(P_pao.getText().toString());

            txt_pao.setText(txt_pao.getText().toString()+ vpao);


        }


    }


    public void calcular(View v){

        if(ch_pao.isChecked()){

            txt_pao.setText("Quantidade De Pães: ");

            vpao = (int) (vpao - Double.parseDouble(P_pao.getText().toString()));

            txt_pao.setText(txt_pao.getText().toString()+vpao);

        }



    }
}