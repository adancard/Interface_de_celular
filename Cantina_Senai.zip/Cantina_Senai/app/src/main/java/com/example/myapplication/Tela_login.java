package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Tela_login extends AppCompatActivity {


    EditText edt_usuario,edt_senha;

    String txt_usuario = "adm",txt_senha="adm";
    Button btn_entrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        edt_usuario = findViewById(R.id.edt_usuario);
        edt_senha = findViewById(R.id.edt_senha);
        btn_entrar = findViewById(R.id.btn_entrar);

    }


    public void Entrar(View v){

        if(edt_usuario.getText().toString().equals(txt_usuario) && edt_senha.getText().toString().equals(txt_senha)){

            Intent intent = new Intent(Tela_login.this,MainActivity.class);
            startActivity(intent);


        }else{

            Toast.makeText(Tela_login.this,"Credenciais incorretas",Toast.LENGTH_SHORT).show();

        }

    }
}