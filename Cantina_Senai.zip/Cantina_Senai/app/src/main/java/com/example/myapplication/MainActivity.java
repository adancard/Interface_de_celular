package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    double Psalgado_N = 6.0,Psalgado_D = 7.50,Ppao = 3.50,Pbala = 0.50,Ppirulito =0.50 ,Prefrigerante = 9.50;
    double vtotal;
    CheckBox ch_salgado_Normal,ch_salgado_Duplo,ch_Pao_De_Queijo,ch_bala,ch_pirulito,ch_refrigerante;
    TextView txt_salgado_Normal,txt_salgado_duplo,txt_pao_de_queijo,txt_bala,txt_pirulito,txt_refrigerante,txt_resultado,txt_codigo;
    EditText edt_salgado_normal,edt_salgado_duplo,edt_pao_de_queijo,edt_bala,edt_pirulito,edt_refrigerante;
    Button btn_comprar;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch_salgado_Normal = findViewById(R.id.chk_salgado_normal);
        ch_salgado_Duplo = findViewById(R.id.chk_salgado_duplo);
        ch_bala = findViewById(R.id.chk_balinha);
        ch_Pao_De_Queijo = findViewById(R.id.chk_salgado_barato);
        ch_refrigerante = findViewById(R.id.chk_refrigerante);
        ch_pirulito = findViewById(R.id.chk_pirulito);

        txt_salgado_Normal = findViewById(R.id.txt_salgado_normal);
        txt_salgado_duplo = findViewById(R.id.txt_salgado_duplo);
        txt_bala = findViewById(R.id.txt_balinha);
        txt_pao_de_queijo = findViewById(R.id.txt_salgado_barato);
        txt_refrigerante = findViewById(R.id.txt_refrigerante);
        txt_pirulito  = findViewById(R.id.txt_pirulito);
        txt_resultado = findViewById(R.id.txt_resultado);
        txt_codigo = findViewById(R.id.txt_codigo);

        edt_salgado_normal = findViewById(R.id.edt_salgado_normal);
        edt_salgado_duplo = findViewById(R.id.edt_salgado_duplo);
        edt_bala = findViewById(R.id.edt_balinha);
        edt_pao_de_queijo = findViewById(R.id.edt_salgado_barato);
        edt_pirulito  = findViewById(R.id.edt_pirulito);
        edt_refrigerante = findViewById(R.id.edt_refrigerante);

        txt_salgado_Normal.setText("Preço:"+Psalgado_N+"\nQuantiade:");
        txt_salgado_duplo.setText("Preço:"+Psalgado_D+"\nQuantiade:");
        txt_bala.setText("Preço:"+Pbala+"\nQuantiade:");
        txt_pao_de_queijo.setText("Preço:"+Ppao+"\nQuantiade:");
        txt_pirulito.setText("Preço:"+Ppirulito+"\nQuantiade:");
        txt_refrigerante.setText("Preço:"+Prefrigerante+"\nQuantiade:");

        btn_comprar = findViewById(R.id.btn_comprar);

        int x = new Random().nextInt(100);

        txt_codigo.setText("Codigo: "+x);


    }
    

    public void comprar(View v){

        if (ch_salgado_Normal.isChecked()){

                double vtotalSalgadoN;

                vtotalSalgadoN = Double.parseDouble(edt_salgado_normal.getText().toString());

                vtotal = vtotal + vtotalSalgadoN * Psalgado_N;

                txt_resultado.setText(String.valueOf(vtotal));

        }

        if (ch_salgado_Duplo.isChecked()){

                double vtotalSalgadoD;

                vtotalSalgadoD = Double.parseDouble(edt_salgado_duplo.getText().toString());

                vtotal += vtotalSalgadoD * Psalgado_D;

                txt_resultado.setText(String.valueOf(vtotal));

        }

        if (ch_bala.isChecked()){

                double vtotalbala;

                vtotalbala = Double.parseDouble(edt_bala.getText().toString());

                vtotal += vtotalbala * Pbala;

                txt_resultado.setText(String.valueOf(vtotal));


        }

        if (ch_pirulito.isChecked()){

                double vtotalPirulito;

                vtotalPirulito = Double.parseDouble(edt_pirulito.getText().toString());

                vtotal = vtotal + vtotalPirulito * Ppirulito;

                txt_resultado.setText(String.valueOf(vtotal));


        }

        if (ch_refrigerante.isChecked()){

                double vtotalRefrigerante;


                vtotalRefrigerante = Double.parseDouble(edt_refrigerante.getText().toString());

                vtotal=vtotal+vtotalRefrigerante * Prefrigerante;

                txt_resultado.setText(String.valueOf(vtotal));


        }

        if (ch_Pao_De_Queijo.isChecked()) {

                double vtotalPao;

                vtotalPao = Double.parseDouble(edt_pao_de_queijo.getText().toString());

                vtotal=vtotal + vtotalPao * Ppao;

                txt_resultado.setText(String.valueOf(vtotal));

        }


    }


}