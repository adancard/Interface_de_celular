package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = (Button) findViewById(R.id.btn);
        Button btn_1 = (Button) findViewById(R.id.btn_1);

        TextView tv_nome = (TextView) findViewById(R.id.txtV_Nome);
        TextView tv_sobrenome = (TextView) findViewById(R.id.txtV_Sobrenome);
        TextView tv_telefone = (TextView) findViewById(R.id.txtV_telefone);
        TextView tv_endereco = (TextView) findViewById(R.id.txtV_endereco);
        TextView tv_cadastro = (TextView) findViewById(R.id.txtV_Final);

        EditText et_nome = (EditText) findViewById(R.id.Et_Nome);
        EditText et_sobrenome = (EditText) findViewById(R.id.Et_Sobrenome);
        EditText et_telefone = (EditText) findViewById(R.id.Et_telefone);
        EditText et_endereco = (EditText) findViewById(R.id.Et_endereco);

        btn_1.setVisibility(View.INVISIBLE);
        tv_cadastro.setVisibility(View.INVISIBLE);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_nome.setText(et_nome.getText());
                tv_sobrenome.setText(et_sobrenome.getText());
                tv_endereco.setText(et_endereco.getText());
                tv_telefone.setText(et_telefone.getText());
                btn_1.setVisibility(View.VISIBLE);
            }
        });

        btn_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                btn_1.setVisibility(View.INVISIBLE);
                tv_cadastro.setVisibility(View.VISIBLE);

            }
        });



    }
}