package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;


public class MainActivity extends AppCompatActivity {

    int Qsalgado_N=10,Qsalgado_D=10,Qpao=10,Qbala=10,Qpirulito=10,Qrefrigerante=10;
    Double Psalgado_N = 6.0,Psalgado_D = 7.50,Ppao = 3.50,Pbala = 0.50,Ppirulito =0.50 ,Prefrigerante = 9.50;
    Double vtotal,vtotalSalgadoN,vtotalbala,vtotalSalgadoD,vtotalPirulito,vtotalRefrigerante,vtotalPao;
    CheckBox ch_salgado_Normal,ch_salgado_Duplo,ch_Pao_De_Queijo,ch_bala,ch_pirulito,ch_refrigerante;
    TextView txt_salgado_Normal,txt_salgado_duplo,txt_pao_de_queijo,txt_bala,txt_pirulito,txt_refrigerante,txt_resultado;
    EditText edt_salgado_normal,edt_salgado_duplo,edt_pao_de_queijo,edt_bala,edt_pirulito,edt_refrigerante;
    Button btn_comprar;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ch_salgado_Normal = findViewById(R.id.chk_salgado_normal);
        ch_salgado_Duplo = findViewById(R.id.chk_salgado_duplo);
        ch_bala = findViewById(R.id.chk_balinha);
        ch_Pao_De_Queijo = findViewById(R.id.chk_salgado_barato);
        ch_refrigerante = findViewById(R.id.chk_refrigerante);
        ch_pirulito = findViewById(R.id.chk_pirulito);

        txt_salgado_Normal = findViewById(R.id.txt_salgado_normal);
        txt_salgado_duplo = findViewById(R.id.txt_salgado_duplo);
        txt_bala = findViewById(R.id.txt_balinha);
        txt_pao_de_queijo = findViewById(R.id.txt_salgado_barato);
        txt_refrigerante = findViewById(R.id.txt_refrigerante);
        txt_pirulito  = findViewById(R.id.txt_pirulito);
        txt_resultado = findViewById(R.id.txt_resultado);

        edt_salgado_normal = findViewById(R.id.edt_salgado_normal);
        edt_salgado_duplo = findViewById(R.id.edt_salgado_duplo);
        edt_bala = findViewById(R.id.edt_balinha);
        edt_pao_de_queijo = findViewById(R.id.edt_salgado_barato);
        edt_pirulito  = findViewById(R.id.edt_pirulito);
        edt_refrigerante = findViewById(R.id.edt_refrigerante);

        txt_salgado_Normal.setText("Preço:"+Psalgado_N+"\nQuantiade:"+Qsalgado_N);
        txt_salgado_duplo.setText("Preço:"+Psalgado_D+"\nQuantiade:"+Qsalgado_D);
        txt_bala.setText("Preço:"+Pbala+"\nQuantiade:"+Qbala);
        txt_pao_de_queijo.setText("Preço:"+Ppao+"\nQuantiade:"+Qpao);
        txt_pirulito.setText("Preço:"+Ppirulito+"\nQuantiade:"+Qpirulito);
        txt_refrigerante.setText("Preço:"+Prefrigerante+"\nQuantiade:"+Qrefrigerante);

        btn_comprar = findViewById(R.id.btn_comprar);
        
        vtotalSalgadoN = Double.parseDouble(edt_salgado_normal.getText().toString());

    }
    

    public void comprar(View v){

        if (ch_salgado_Normal.isChecked()){

            if(Qsalgado_N > 0){

               vtotal= vtotal + vtotalSalgadoN * Psalgado_N;

                txt_resultado.setText("Total da compra: "+vtotal);

            }
            else{

                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Salgado fora do estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            }

        }

        if (ch_salgado_Duplo.isChecked()){

                vtotalSalgadoD = Double.parseDouble(edt_salgado_duplo.getText().toString()) * Psalgado_D;

                vtotal=vtotal+vtotalSalgadoD;

                txt_resultado.setText(vtotal.toString());






        }

        if (ch_bala.isChecked()){


            if(Qbala > 0 ) {

                vtotalbala = Double.parseDouble(edt_bala.getText().toString()) * Pbala;
                vtotal=vtotal+vtotalbala;

                txt_resultado.setText(vtotal.toString());
            }else{


                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Bala esta fora de Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            }

        }

        if (ch_pirulito.isChecked()){

            if(Qpirulito > 0 ) {
                vtotalPirulito = Double.parseDouble(edt_pirulito.getText().toString()) * Ppirulito;
                vtotal=vtotal+vtotalPirulito;

                txt_resultado.setText(vtotal.toString());
            }else {


                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Pirulito esta fora de Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            }

        }

        if (ch_refrigerante.isChecked()){

            if(Qrefrigerante > 0) {

                vtotalRefrigerante = Double.parseDouble(edt_refrigerante.getText().toString()) * Prefrigerante;
                vtotal=vtotal+vtotalRefrigerante;

                txt_resultado.setText(vtotal.toString());

            }else {


                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Refrigerante esta fora de Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            }


        }

        if (ch_Pao_De_Queijo.isChecked()) {

            if(Qpao > 0 ) {
                vtotalPao = Double.parseDouble(edt_pao_de_queijo.getText().toString()) * Ppao;
                vtotal=vtotal+vtotalPao;

                txt_resultado.setText(vtotal.toString());
            }else{


                AlertDialog.Builder cxMsg = new AlertDialog.Builder(this);
                cxMsg.setMessage("Pão de Queijo esta fora de Estoque");
                cxMsg.setNeutralButton("OK", null);
                cxMsg.show();

            }

        }




    }






}